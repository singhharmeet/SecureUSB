/*
Java Class to search for encrypted or normal files after drive is detected.
*/
package front;


import EncryptionDecryption.searchDir;
import java.io.*;
import javax.swing.JOptionPane;

public class FindCertainExtension {
public static String c=new String();
private static int flag=0;
	private static final String FILE_TEXT_EXT = ".encrypted";

	public static void launch(String arg0) {
            c=arg0;
            c=c.concat(":\\");
            new FindCertainExtension().listFile(c, FILE_TEXT_EXT);
	}

	public void listFile(String folder, String ext) {

		GenericExtFilter filter = new GenericExtFilter(ext);

		File dir = new File(folder);
		
		if(dir.isDirectory()==false){
			JOptionPane.showMessageDialog(null, "Directory does not exists!!");
                        return;
		}
		
                
		String[] list = dir.list(filter);
                String[] list1=dir.list();
                
               for(int x=0;x<list1.length;x++)
               {
               if (list1[x].equals("System Volume Information"))
                    {
                    flag=1;
                    break;
                    }
               }
                
                
                if(list1.length==1&&flag==1)
                {
                   flag=0;
                    String str1="xcopy C:\\Backup\\1.encrypted "+c+" /K /I /R /H /Y /D"; 
                       String str2="xcopy C:\\Backup\\2.encrypted "+c+" /K /I /R /H /Y /D"; 
                       System.out.println(str1);
                       System.out.println(str2);
                       try{
                       Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c",str1});
                        Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c",str2});
                        searchDir.launch();
                        
                       }catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
                                        }

                }
                else if (list1.length != 0&&list.length==0) {
                EncryptionDecryption.Encryption.launch(1);
                }
                else{
		for (String file : list) {
                    if(file.indexOf('1')==0)
                    {
			String temp = new StringBuffer(c).append(File.separator)
					.append(file).toString();
			System.out.println("file : " + temp);
                        EncryptionDecryption.Decryption.launch(1);
                    }   
                    else
                    {
                    String temp = new StringBuffer(c).append(File.separator)
					.append(file).toString();
			System.out.println("file : " + temp);
                        EncryptionDecryption.Decryption.launch(2);
                    }
		}
	}
        }
	// inner class, generic extension filter
	public class GenericExtFilter implements FilenameFilter {

		private String ext;

		public GenericExtFilter(String ext) {
			this.ext = ext;
		}

		public boolean accept(File dir, String name) {
			return (name.endsWith(ext));
		}
	}
}
/*
Class showing the introduction template.

AUTHORS-
Harmeet Singh
Simrandeep Singh
Amandeep Singh

Licensing and Distribution Terms:-
use,distribute and modify software as you like!!
*/


import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.JLabel;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Toolkit;
//import java.awt.event.ActionListener
public class main{

	/**
	 * Launch the application.
     * @param args
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
                    try {
                        main window1 = new main();
                           
                    } catch (Exception e) {
                    }
                });
	}

	/**
	 * Create the application.
	 */
	public main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		JFrame a= new JFrame("SecureUSB");
                a.setIconImage(Toolkit.getDefaultToolkit().getImage("src/resources/icon.jpg"));
		a.setSize( 450, 300);
		
                a.setLocationRelativeTo(null);
		
                a.setVisible(true);
a.setResizable(false);   
		
                a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel label = new JLabel(new ImageIcon("src/resources/SecureUSB.jpg"));
		
		a.setContentPane(label);
                
		a.setLayout(new FlowLayout());
                		
		JPanel panel = new JPanel();
		panel.setOpaque(false);
		
		a.getContentPane().add(panel, BorderLayout.CENTER);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JLabel lblSecureusb = new JLabel("SecureUSB");
		lblSecureusb.setOpaque(false);
		lblSecureusb.setForeground(Color.WHITE);
		lblSecureusb.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		GridBagConstraints gbc_lblSecureusb = new GridBagConstraints();
		gbc_lblSecureusb.gridwidth = 3;
		gbc_lblSecureusb.insets = new Insets(0, 0, 5, 5);
		gbc_lblSecureusb.gridx = 1;
		gbc_lblSecureusb.gridy = 1;
		panel.add(lblSecureusb, gbc_lblSecureusb);
		
		JLabel lblMadeBy = new JLabel("Made By-");
		lblMadeBy.setOpaque(false);
		lblMadeBy.setForeground(Color.WHITE);
                lblMadeBy.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		GridBagConstraints gbc_lblMadeBy = new GridBagConstraints();
		gbc_lblMadeBy.insets = new Insets(0, 0, 5, 5);
		gbc_lblMadeBy.gridx = 7;
		gbc_lblMadeBy.gridy = 4;
		panel.add(lblMadeBy, gbc_lblMadeBy);
		
		JLabel lblHarmeetSinghcsegtbit = new JLabel("Harmeet Singh");
		lblHarmeetSinghcsegtbit.setOpaque(false);
		lblHarmeetSinghcsegtbit.setForeground(Color.WHITE);
                lblHarmeetSinghcsegtbit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		GridBagConstraints gbc_lblHarmeetSinghcsegtbit = new GridBagConstraints();
		gbc_lblHarmeetSinghcsegtbit.insets = new Insets(0, 0, 5, 0);
		gbc_lblHarmeetSinghcsegtbit.gridwidth = 9;
		gbc_lblHarmeetSinghcsegtbit.gridx = 4;
		gbc_lblHarmeetSinghcsegtbit.gridy = 6;
		panel.add(lblHarmeetSinghcsegtbit, gbc_lblHarmeetSinghcsegtbit);
		
		JButton btnOpen = new JButton("Open");
		btnOpen.addActionListener((ActionEvent e) -> {
                    String cmd = e.getActionCommand();
                    
                    if(cmd.equals("Open"))
                    {
                        a.setVisible(false); //you can't see me!
                        a.dispose();
                        EncryptionDecryption.searchDir.launch();
                        
                        
                    }
                });
                
		GridBagConstraints gbc_btnOpen = new GridBagConstraints();
		gbc_btnOpen.insets = new Insets(0, 0, 5, 5);
		gbc_btnOpen.gridx = 3;
		gbc_btnOpen.gridy = 7;
		panel.add(btnOpen, gbc_btnOpen);
		
		JLabel lblAmamdeepSinghcsegtbit = new JLabel("Amamdeep Singh");
		lblAmamdeepSinghcsegtbit.setOpaque(false);
		lblAmamdeepSinghcsegtbit.setForeground(Color.WHITE);
                lblAmamdeepSinghcsegtbit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		GridBagConstraints gbc_lblAmamdeepSinghcsegtbit = new GridBagConstraints();
		gbc_lblAmamdeepSinghcsegtbit.insets = new Insets(0, 0, 5, 0);
		gbc_lblAmamdeepSinghcsegtbit.gridwidth = 9;
		gbc_lblAmamdeepSinghcsegtbit.gridx = 4;
		gbc_lblAmamdeepSinghcsegtbit.gridy = 7;
		panel.add(lblAmamdeepSinghcsegtbit, gbc_lblAmamdeepSinghcsegtbit);
		
		JLabel lblSimrandeepSinghcsegtbit = new JLabel("Simrandeep Singh");
		lblSimrandeepSinghcsegtbit.setOpaque(false);
		lblSimrandeepSinghcsegtbit.setForeground(Color.WHITE);
                lblSimrandeepSinghcsegtbit.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		GridBagConstraints gbc_lblSimrandeepSinghcsegtbit = new GridBagConstraints();
		gbc_lblSimrandeepSinghcsegtbit.gridwidth = 9;
		gbc_lblSimrandeepSinghcsegtbit.gridx = 4;
		gbc_lblSimrandeepSinghcsegtbit.gridy = 8;
		panel.add(lblSimrandeepSinghcsegtbit, gbc_lblSimrandeepSinghcsegtbit);
	}

}



/*
 Main Clas that invokes CryptoUtils class
 */
package EncryptionDecryption;

import java.io.File;
import java.util.Scanner;

public class CryptoUtilsTest {
	int i;
        static String key=new String();
        static String ALGORITHM=new String();
        static int x0;
        static int y0;
        static File encryptedFile;
    static File inputFile;
    static File decryptedFile;
        static String TRANSFORMATION=new String();
	public static void main(String pass,int x,int ed) {
		key = pass;
        x0=x;
       y0=ed;
	inputFile= new File(searchDir.Dname()+":\\Newfolder.zip");
	
	decryptedFile = new File(searchDir.Dname()+":\\files.zip");
        
	if(x0==2)
         encryptedFile = new File(searchDir.Dname()+":\\"+"2.encrypted");
        else
         encryptedFile = new File(searchDir.Dname()+":\\"+"1.encrypted");
		CryptoUtilsTest a=new CryptoUtilsTest();
                               
		a.fun3();
            
	}
	public void fun3()
	{
            if(y0==0){
		if(x0==1)
                {TRANSFORMATION="AES";
                ALGORITHM="AES";
                    fun1();}
                else if(x0==2){
		
                TRANSFORMATION="DES";
                ALGORITHM="DES";
                fun1();                    }
            }
            else
            {
           if(x0==1)
                {TRANSFORMATION="AES";
                ALGORITHM="AES";
                    fun2();}
                else if(x0==2){
		
                TRANSFORMATION="DES";
                ALGORITHM="DES";
                fun2();                    }
            
            }
        }
	public void fun1()
	{
		try {
			CryptoUtils.encrypt(key, inputFile, encryptedFile,ALGORITHM,TRANSFORMATION, searchDir.Dname()+":\\Newfolder");
		} catch (CryptoException e) {
			e.printStackTrace();
		}
	}
	public void fun2()
	{
		try {
			CryptoUtils.decrypt(key, encryptedFile, decryptedFile,ALGORITHM,TRANSFORMATION,searchDir.Dname()+":\\Newfolder" );
		} catch (CryptoException e) {
			e.printStackTrace();
		}
	}
}

package EncryptionDecryption;
import java.io.File;
import javax.swing.JOptionPane;


/*
Program to detect drive when inserted
*/

public class searchDir {
    static String c;
    public static int launch1()
    {
        launch();
    return 1;
    }
    public static void launch()
    {

    String[] letters = new String[]{ "A", "B", "C", "D", "E", "F", "G", "H", "I"};
    File[] drives = new File[letters.length];
    boolean[] isDrive = new boolean[letters.length];

    // init the file objects and the initial drive state
    for ( int i = 0; i < letters.length; ++i )
        {
        drives[i] = new File(letters[i]+":/");

        isDrive[i] = drives[i].canRead();
        }

 int j=1;
	     while(j>0)
	        {
	        for ( int i = 0; i < letters.length; ++i )
	            {
	            boolean pluggedIn = drives[i].canRead();

	            if ( pluggedIn != isDrive[i] )
	                {
	                if ( pluggedIn )
	                    {
                                j=0;
                            JOptionPane.showMessageDialog(null, "Usb Device Found:-"+letters[i]);
                        
	                    c=letters[i];
                            front.FindCertainExtension.launch(c);
                            }
	                isDrive[i] = pluggedIn;
	                }
	            }

        try { Thread.sleep(100); }
        catch (InterruptedException e) { /* do nothing */ }

        }
    }

    
public static String Dname()
	{
		return c;
	}
}

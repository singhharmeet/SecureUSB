/*
Java Class for file hiding
*/
package EncryptionDecryption;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class fileHiding {
public static void hide(String drive,String fname)
{
	String str;
	str="attrib +r +s +h \""+drive+":\\"+fname+"\" ";
        String strx="rd /s /q C:\\Backup";
        String str0="md C:\\Backup";
       String str1="xcopy "+drive+":\\"+fname+" C:\\Backup\\ /I /K /R /H /Y /D";

	System.out.println(str);
        System.out.println(str0);
        System.out.println(strx);
        
        System.out.println(str1);
	try {
		Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c",str});

              Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c",strx});
                Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c",str0});
              
               ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", str1);
        builder.redirectErrorStream(true);
        Process p = builder.start();
        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while (true) {
            line = r.readLine();
            if (line == null) { break; }
            System.out.println(line);
        } 
               
        } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public static void unhide(String drive,String fname)
{
	String str;
	str="attrib -r -s -h \""+drive+":\\"+fname+"\" ";
	System.out.println(str);
	try {
		Runtime.getRuntime().exec(new String[]{"cmd.exe", "/c",str});
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

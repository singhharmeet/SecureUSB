/*
Accumulator class to accumulate files
*/
package EncryptionDecryption;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class accu {
    
    
	public static List<String> fileList;
	public static void accum(String SOURCE_FOLDER)
	{
		fileList = new ArrayList<String>();
	    generateFileList(new File(SOURCE_FOLDER), SOURCE_FOLDER);
	   try{
	    File batfile = new File("G:\\filename.bat");
		if (!batfile.exists()) {
			batfile.createNewFile();
		}
		FileWriter fw = new FileWriter(batfile.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		String mdstr="md "+searchDir.Dname()+":\\Newfolder";
		bw.write(mdstr);
		bw.newLine();
		System.out.println(fileList.isEmpty());	
	    for(String file : fileList)
	    {
	    	System.out.println("file(s) added");
	    	String str;
	    	str="move "+"\""+searchDir.Dname()+":\\"+file.toString()+"\" \""+searchDir.Dname()+":\\Newfolder"+"\\"+file+"\"";
	    	bw.write(str);
	    	bw.newLine();
	    }
	    
	    bw.write("echo temporary file,can be deleted>>"+searchDir.Dname()+":\\new.txt");
	    bw.newLine();
	    bw.write("exit(0)");
		bw.close();
		Runtime.getRuntime().exec("cmd /c start "+searchDir.Dname()+":\\filename.bat");
		File f=new File(searchDir.Dname()+":\\new.txt");
		
		for(;!(f.exists());){
			int j=1;
			long s=System.currentTimeMillis();
			for(;j==1;)
			{
				if(System.currentTimeMillis()-s>=3000)
					j=0;
			}
		System.out.println("waiting for love...");
		}
              f.delete();
		batfile.delete();
		}
	   catch(IOException ex){
	          ex.printStackTrace(); 
	       }
	}
	public static void generateFileList(File node,String SOURCE_FOLDER){

	    if(node.isFile()){
			fileList.add(generateEntry(node.getAbsoluteFile().toString(),SOURCE_FOLDER));
		}
		String name = node.getName();
                int pos = name.lastIndexOf(".");
                if (pos >= 0) {
                name = name.substring(0, pos);
                }	
		if(node.isDirectory()&&!(name.equals("System Volume Information"))){
			String[] subNote = node.list();
			for(String filename : subNote){
				generateFileList(new File(node, filename),SOURCE_FOLDER);
			}
		}
	 
}
	public static String generateEntry(String file,String SOURCE_FOLDER){
    	return file.substring(SOURCE_FOLDER.length(), file.length());
    }

}
